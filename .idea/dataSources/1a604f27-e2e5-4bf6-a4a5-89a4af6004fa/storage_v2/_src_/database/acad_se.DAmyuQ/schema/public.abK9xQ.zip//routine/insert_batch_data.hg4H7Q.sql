create procedure insert_batch_data(batchyear integer, min_credits integer, min_program_electives integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO batch VALUES (batchYear, min_credits, min_program_electives);
END;
$$;

alter procedure insert_batch_data(integer, integer, integer) owner to postgres;

