create procedure insert_semester_data(semesters character varying, academic_year integer, is_current_semester boolean)
    language plpgsql
as
$$
BEGIN
    INSERT INTO semester VALUES (semesterS, academic_year, is_current_semester);
END;
$$;

alter procedure insert_semester_data(varchar, integer, boolean) owner to postgres;

