create procedure insert_course_catalog_data(course_code character varying, course_name character varying, credit_structure character varying, prerequisites integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO course_catalog VALUES (course_code, course_name, credit_structure, prerequisites);
END;
$$;

alter procedure insert_course_catalog_data(varchar, varchar, varchar, integer) owner to postgres;

