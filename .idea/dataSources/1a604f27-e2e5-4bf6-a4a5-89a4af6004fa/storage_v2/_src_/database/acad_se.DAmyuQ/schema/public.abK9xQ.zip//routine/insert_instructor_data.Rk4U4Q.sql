create procedure insert_instructor_data(instructor_id integer, name character varying, email character varying, department character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO instructor VALUES (instructor_id, name, email, department);
END;
$$;

alter procedure insert_instructor_data(integer, varchar, varchar, varchar) owner to postgres;

