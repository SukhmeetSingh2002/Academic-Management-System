create procedure deregister_course(_student_entry_number integer, _course_code character varying, _semester character varying)
    language plpgsql
as
$$
BEGIN
    DELETE FROM student_course_registration WHERE student_id = _student_entry_number AND course_code = _course_code AND semester = _semester;
END;
$$;

alter procedure deregister_course(integer, varchar, varchar) owner to postgres;

