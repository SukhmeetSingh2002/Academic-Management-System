create procedure update_current_semester(semesterp character varying, academic_yearp integer)
    language plpgsql
as
$$
BEGIN
    UPDATE semester SET is_current_semester = FALSE WHERE is_current_semester = TRUE;
    UPDATE semester SET is_current_semester = TRUE WHERE semester = semesterP AND academic_year = academic_yearP;
END;
$$;

alter procedure update_current_semester(varchar, integer) owner to postgres;

