create procedure insert_course_offerings_data(course_code character varying, semester character varying, instructor_id integer, cgpa_constraint double precision)
    language plpgsql
as
$$
BEGIN
    INSERT INTO course_offerings VALUES (course_code, semester, instructor_id, cgpa_constraint);
END;
$$;

alter procedure insert_course_offerings_data(varchar, varchar, integer, double precision) owner to postgres;

