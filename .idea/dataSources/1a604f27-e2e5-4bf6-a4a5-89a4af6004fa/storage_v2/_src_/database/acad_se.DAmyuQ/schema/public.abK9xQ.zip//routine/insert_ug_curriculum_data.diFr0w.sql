create procedure insert_ug_curriculum_data(batch integer, course_code character varying, course_type character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO ug_curriculum VALUES (batch, course_code, course_type);
END;
$$;

alter procedure insert_ug_curriculum_data(integer, varchar, varchar) owner to postgres;

