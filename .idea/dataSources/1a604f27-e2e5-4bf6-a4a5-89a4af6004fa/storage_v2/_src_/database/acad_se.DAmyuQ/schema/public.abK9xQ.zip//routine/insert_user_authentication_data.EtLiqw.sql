create procedure insert_user_authentication_data(user_id integer, password character varying, role character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO user_authentication VALUES (user_id, password, role);
END;
$$;

alter procedure insert_user_authentication_data(integer, varchar, varchar) owner to postgres;

