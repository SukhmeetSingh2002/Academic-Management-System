create procedure insert_grade_entry_data(student_entry_number integer, course_code character varying, semester character varying, grade character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO grade_entry VALUES (student_entry_number, course_code, semester, grade);
END;
$$;

alter procedure insert_grade_entry_data(integer, varchar, varchar, varchar) owner to postgres;

