create procedure insert_student_course_registration_data(student_entry_number integer, course_code character varying, semester character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO student_course_registration VALUES (student_entry_number, course_code, semester);
END;
$$;

alter procedure insert_student_course_registration_data(integer, varchar, varchar) owner to postgres;

