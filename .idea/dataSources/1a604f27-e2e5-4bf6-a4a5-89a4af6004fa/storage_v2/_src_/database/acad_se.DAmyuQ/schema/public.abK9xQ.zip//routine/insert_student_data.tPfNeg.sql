create procedure insert_student_data(entry_number character varying, name character varying, email character varying, batch integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO student VALUES (entry_number, name, email, batch);
END;
$$;

alter procedure insert_student_data(varchar, varchar, varchar, integer) owner to postgres;

