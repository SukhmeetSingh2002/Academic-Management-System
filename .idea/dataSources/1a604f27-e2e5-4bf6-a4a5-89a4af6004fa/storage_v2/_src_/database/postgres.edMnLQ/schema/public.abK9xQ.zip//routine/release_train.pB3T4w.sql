create function release_train(train_name character varying, ac_coaches integer, seats_ac_coach integer, sl_coaches integer, seats_sl_coach integer) returns void
    language plpgsql
as
$$
DECLARE
	traniname_ac VARCHAR := train_name || '_AC';
	traniname_sl VARCHAR := train_name || '_SL';
	total_ac_seats INTEGER := ac_coaches * seats_ac_coach;
	total_sl_seats INTEGER := sl_coaches * seats_sl_coach;
BEGIN 

	execute 'CREATE TABLE '|| traniname_ac ||'(
		coach_number INT,
		seat_number INT,
		available INT,
		PRIMARY KEY(coach_number, seat_number)
	)' ;

	execute 'CREATE TABLE '|| traniname_sl ||'(
		coach_number INT,
		seat_number INT,
		available INT,
		PRIMARY KEY(coach_number, seat_number)
	)' ;

	-- insert 100 rows in each table without using loop
    	execute 'INSERT INTO '|| traniname_ac ||' (coach_number, seat_number, available)
		SELECT s, t, 1
		FROM generate_series(1,'|| ac_coaches ||') s, generate_series(1,'|| seats_ac_coach ||') t' ;

	execute 'INSERT INTO '|| traniname_sl ||' (coach_number, seat_number, available)
		SELECT s, t, 1
		FROM generate_series(1,'|| sl_coaches ||') s, generate_series(1,'|| seats_sl_coach ||') t' ;


END; 
$$;

alter function release_train(varchar, integer, integer, integer, integer) owner to postgres;

