create function check_train_exists(trainname character varying) returns boolean
    language plpgsql
as
$$
begin
    return exists(select table_name from information_schema.tables where table_name = trainName);
end;
$$;

alter function check_train_exists(varchar) owner to postgres;

