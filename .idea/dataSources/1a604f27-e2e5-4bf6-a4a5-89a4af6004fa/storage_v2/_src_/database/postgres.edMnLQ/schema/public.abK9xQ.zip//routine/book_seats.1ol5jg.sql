create function book_seats(train_name character varying, number_of_passengers integer) returns integer
    language plpgsql
as
$$
-- declare a cursor to store rows from train table
declare
    -- c1 refcursor;
    -- c2 refcursor;
-- declare a variable to store the number of rows updated
    last_coach int;
    last_seat int;
    concatenated_string varchar;
    available int;
    return_value int;
    number_of_rows int;
begin
    number_of_rows := 0;
    return_value := -1;
    -- open c1  for execute format(
    --     'select * from %I where available = 1 for update skip locked LIMIT ($1) ',train_name)
    --     USING number_of_passengers;
----------------------NEED to add available =1--------------------------
    -- if (c1 is not NULL) then
        -- update the available column to 0 without using loop 
        execute format('update %I set available = 0 where available = 1 LIMIT ($1)',train_name) USING number_of_passengers;
        -- get the number of rows updated
        get diagnostics number_of_rows = row_count;
        -- if number of rows updated is equal to number of passengers
        last_coach := 0;
        last_seat := 0;
        return_value := 10;
        -- raise notice 'return value: %', return_value;
        -- close c1;
        if (number_of_rows = number_of_passengers) then
            return return_value;
        else
            return -1;
        end if;
        return return_value;
    -- end if;
    -- close c1;
    return -1;
end;
$$;

alter function book_seats(varchar, integer) owner to postgres;

