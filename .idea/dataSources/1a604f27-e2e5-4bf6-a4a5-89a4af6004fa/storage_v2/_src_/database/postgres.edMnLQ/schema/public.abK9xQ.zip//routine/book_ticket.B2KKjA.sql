create procedure book_ticket(trainname character varying, number_passenger integer, passenger_names character varying, seats_ac_coach integer, seats_sl_coach integer, INOUT return_variable integer)
    language plpgsql
as
$$
declare 
    seats_available boolean := false;
    passenger_name varchar;
    train_details varchar[] :=string_to_array(trainName,'_');
    pnr_number varchar;
    coach_number int:=0;
    seat_number int:=0;
    seat_info integer;
    temp_seat_info varchar[];
    passenger_name_array varchar[] :=string_to_array(passenger_names,',');
begin
            -- SET Transaction Isolation Level SERIALIZABLE;
    if (check_train_exists(trainName)) then
        for i in 1..3 loop
            seat_info := book_seats(trainName, number_passenger);
            -- raise notice 'Your seat: %  where i is : %',seat_info,i;
            if (seat_info <>-1) then
                seats_available := true;
                COMMIT;
                exit;
            ELSE
                ROLLBACK;
            end if;
        end loop;

        if (seats_available) then
            pnr_number :=train_details[2] || train_details[3] || seat_info ||train_details[4];
            return_variable:=seat_info;
            coach_number := seat_info/100;
            seat_number := seat_info%100;
            -- raise notice 'train details: %, ',train_details;
            insert into ticket  values (pnr_number,train_details[2] ::DECIMAL, to_date(train_details[3],'YYYYMMDD'), number_passenger, train_details[4]);
            foreach passenger_name in array passenger_name_array loop
                -- insert into ticket table 
                insert into passenger(passenger_name,PNR,coach_number,seat_number) values (passenger_name, pnr_number, coach_number, seat_number);
                seat_number := seat_number - 1;
                if (seat_number = 0) then
                    coach_number := coach_number - 1;
                    seat_number := seats_ac_coach;
                    if(train_details[4] = 'sl') then
                        seat_number := seats_sl_coach;
                    end if;
                end if;
            end loop;
            COMMIT;
        else
            -- raise exception 'No seats available';
            ROLLBACK;
            return_variable := -1;
        end if;
    else
        -- ? To check this
        -- raise exception 'train does not exist';
        return_variable := -2;
    end if;
end;
$$;

alter procedure book_ticket(varchar, integer, varchar, integer, integer, inout integer) owner to postgres;

