create function release_train(trainname character varying, ac_coaches integer, seats_ac_coach integer, sl_coaches integer, seats_sl_coach integer) returns void
    language plpgsql
as
$$
DECLARE
	traniname_ac VARCHAR := 'ac_' || trainName ;
	traniname_sl VARCHAR := 'sl_' || trainName  ;
	total_ac_seats INTEGER := ac_coaches * seats_ac_coach;
	total_sl_seats INTEGER := sl_coaches * seats_sl_coach;
BEGIN 
------------------------- For testing begin-------------------
    execute 'Drop table if exists '|| traniname_ac ;
    execute 'Drop table if exists '|| traniname_sl;

------------------------- For testing end-------------------

	execute 'CREATE TABLE '|| traniname_ac ||' (
		coach_number INT,
		seat_number INT,
		available INT,
		PRIMARY KEY(coach_number, seat_number)
	)' ;

	execute 'CREATE TABLE '|| traniname_sl ||' (
		coach_number INT,
		seat_number INT,
		available INT,
		PRIMARY KEY(coach_number, seat_number)
	)' ;

	FOR seat in 0..(total_ac_seats-1) LOOP
		execute 'INSERT INTO '|| traniname_ac ||' VALUES('|| seat/seats_ac_coach +1 ||','|| mod(seat,seats_ac_coach)+1 ||',1)';
	END LOOP;

	FOR seat in 0..(total_sl_seats-1) LOOP
		execute 'INSERT INTO '|| traniname_sl ||' VALUES('|| seat/seats_sl_coach +1 ||','|| mod(seat,seats_sl_coach)+1 ||',1)';
	END LOOP;
    -- execute 'INSERT INTO '|| traniname_ac ||' (coach_number, seat_number, available)
    --             SELECT s, t, 1
    --             FROM generate_series(1,'|| ac_coaches ||') s, generate_series(1,'|| seats_ac_coach ||') t' ;

    -- execute 'INSERT INTO '|| traniname_sl ||' (coach_number, seat_number, available)
    --         SELECT s, t, 1
    --         FROM generate_series(1,'|| sl_coaches ||') s, generate_series(1,'|| seats_sl_coach ||') t' ;
END; 
$$;

alter function release_train(varchar, integer, integer, integer, integer) owner to postgres;

