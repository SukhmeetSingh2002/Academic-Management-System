create function book_seats(trainname character varying, number_passenger integer, passenger_names character varying) returns character varying
    language plpgsql
as
$$
-- declare a cursor to store rows from train table
declare
    c1 refcursor;
    -- c2 refcursor;
    coach int;
    seat int;
    available int;
    concatenated_string varchar := 't';
    train_details varchar[] :=string_to_array(trainName,'_');
    passenger_name_array varchar[] :=string_to_array(passenger_names,',');
    pnr_number varchar;
    idx int:=1;
    indicator int :=0; -- to check if seats are assigned or not.
    train_date DATE;
begin

    open c1  for execute format(
        'select * from %I where available = 1 
        for update skip locked
        LIMIT (
        CASE
            WHEN (select Count(*) from (
                select * from %I where available = 1 
                for update  skip locked
                limit $1 ) as temp) >= $1 
                THEN $1 
            ELSE 0
            END
        )',trainName,trainName)
        USING number_passenger;

    train_date := to_date(train_details[3],'YYYYMMDD');
    -- update train set available = 0 where train_name = trainName and train_date = train_date curent in CURSOR
    loop
        fetch c1 into coach,seat,available;
        exit when not found;
        indicator :=1;
        if idx = 1 then
            pnr_number :=train_details[2] || train_details[3]|| coach*100 + seat ||train_details[1]; -- generating the pnr
            insert into ticket  values (pnr_number,train_details[2] ::DECIMAL, train_date, number_passenger, train_details[1]); -- inserting the ticket details
        end if;

        execute  format('update ' || trainName || ' set available = 0 where coach_number = $1 and  seat_number = $2')
        USING coach,seat,number_passenger; --toggling the availability of seat booked.
        
        insert into passenger(passenger_name,PNR,coach_number,seat_number) values (passenger_name_array[idx],pnr_number,coach,seat);
        -- Inserting passenger details
        concatenated_string := concatenated_string || ' ' || coach*100 + seat;
        --updating the string to be returned
        idx := idx + 1;
    end loop;
    close c1;
    IF indicator = 0 then
            concatenated_string := '-1'; -- Case when no seats are available
    END IF;
    return concatenated_string;
end;
$$;

alter function book_seats(varchar, integer, varchar) owner to postgres;

