create procedure book_ticket(trainname character varying, number_passenger integer, passenger_names character varying, seats_ac_coach integer, seats_sl_coach integer, INOUT return_variable character varying)
    language plpgsql
as
$$
declare 
    -- temp int;
begin
    if (check_train_exists(trainName)) THEN -- if train exists
        for i in 1..3 loop
            return_variable := book_seats(trainName, number_passenger,passenger_names);
            if (return_variable <>'-1') THEN  -- if seats are available
                COMMIT;
                exit;
            -- ELSE            --When seats are not available
            --     -- execute format('select count(*) from (select available from '|| trainName|| ' where available =1 ) as t1')
            --     -- into temp;
            --     -- if temp < number_passenger THEN
            --     --     COMMIT;
            --     --     exit;
            --     -- END IF;
                 ROLLBACK;
            end if;
        end loop;
    else
        return_variable :='-2'; --if train does not exist
        COMMIT;
    end if;
    COMMIT;
end;
$$;

alter procedure book_ticket(varchar, integer, varchar, integer, integer, inout varchar) owner to postgres;

